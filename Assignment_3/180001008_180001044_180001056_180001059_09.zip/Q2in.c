void func(){
  int a,b,c,d;
  scanf("%d",a);
  printf("HELLO\n");
  scanf("%d",b);
  printf("HELLO\n");
  scanf("%d",c);
  printf("HELLO\n");
  scanf("%d",d);
}
